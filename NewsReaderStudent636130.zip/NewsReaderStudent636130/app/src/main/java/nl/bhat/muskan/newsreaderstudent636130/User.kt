package nl.bhat.muskan.newsreaderstudent636130

data class User (val username: String, val password: String)