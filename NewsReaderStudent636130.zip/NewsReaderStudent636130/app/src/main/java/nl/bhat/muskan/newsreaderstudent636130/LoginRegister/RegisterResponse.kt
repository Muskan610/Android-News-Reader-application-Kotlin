package nl.bhat.muskan.newsreaderstudent636130.LoginRegister

class RegisterResponse(var Success: Boolean, var Message: String)