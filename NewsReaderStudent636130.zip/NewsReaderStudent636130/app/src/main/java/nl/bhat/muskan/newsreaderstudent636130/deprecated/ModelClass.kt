package nl.bhat.muskan.newsreaderstudent636130.deprecated

data class ModelClass(
    var Title: String,
    var Summary: String,
    var PublishDate: String,
    var Image: String,
    var Url: String
)