package nl.bhat.muskan.newsreaderstudent636130.LoginRegister

data class LoginResponse (
    var AuthToken: String
)