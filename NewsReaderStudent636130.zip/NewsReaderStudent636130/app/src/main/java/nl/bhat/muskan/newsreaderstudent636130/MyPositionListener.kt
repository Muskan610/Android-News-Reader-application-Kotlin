package nl.bhat.muskan.newsreaderstudent636130

interface MyPositionListener {
    fun onItemClicked(position: Int)
}