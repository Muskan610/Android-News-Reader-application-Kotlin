package nl.bhat.muskan.newsreaderstudent636130

data class LoginResponse(
    val AuthToken: String
)