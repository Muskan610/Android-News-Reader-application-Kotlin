package nl.bhat.muskan.newsreaderstudent636130.LoginRegister

class LoginRequest(var userName: String, var password: String)