package nl.bhat.muskan.newsreaderstudent636130.deprecated

import java.util.*

class mainNews(var IsLiked: String, var count: String, var Results: ArrayList<ModelClass>)
//totalResults is count in our api context